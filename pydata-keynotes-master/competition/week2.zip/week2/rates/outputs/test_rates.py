from macao_rates import latest_cny_mop
rate = latest_cny_mop()
print(100*rate)
